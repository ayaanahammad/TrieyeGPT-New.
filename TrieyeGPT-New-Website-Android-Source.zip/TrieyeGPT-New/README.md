# TrieyeGPT — New Independent AI Project

This is a **new standalone project**. It does not modify NEXORA AI or require its GitHub repository.

## Included
- `public/`: responsive TrieyeGPT website and installable Android PWA.
- `server.js`: Node.js server and real OpenAI chat API integration.
- `android-app/`: Android Studio Java project for building a native **WebView APK** that opens your deployed TrieyeGPT website. This is a native Android container, **not** an offline AI engine.

## Deploy the website
1. Create a **new** GitHub repository, e.g. `TrieyeGPT-New`.
2. Upload the files from this project root, keeping `public/` as a folder. Do not upload API keys.
3. Create a new Render **Web Service** connected to the new repository. Root directory blank, runtime Node, build `npm install`, start `npm start`.
4. In Render Environment set `OPENAI_API_KEY` to your **new, private** API key. Optional: `OPENAI_MODEL=gpt-4o-mini` and `TRIEYE_ACCESS_PASSWORD` to a private password.
5. Deploy. Test `https://YOUR-SERVICE.onrender.com/api/health` and chat.

## Install the Android PWA
Open the HTTPS website in Android Chrome, then select **Install app** (or Add to Home screen).

## Build a native Android APK
1. Install Android Studio on a computer or use a trusted Android build service with your own project.
2. Open `android-app/` as an Android Studio project. Let Gradle sync and install any requested SDK components.
3. Change `android-app/app/src/main/res/values/strings.xml`: replace `https://YOUR-TRIEYEGPT-SERVICE.onrender.com` with your actual **HTTPS Render URL**.
4. Choose **Build > Build APK(s)**. Android Studio produces `app-debug.apk` for testing. For distribution, create and sign a release APK/AAB.
5. The Android app requires internet access to the deployed website and its backend.

## Security and limitations
- Never paste API keys into GitHub, HTML, JavaScript, Android resources, or chats.
- The website stores chat history in the browser's local storage; it is not synchronized across devices.
- This v1 provides text chat; voice, image understanding, agents, cloud history, and offline models are **not implemented**.
- Fast/Smart/Deep are prompt presets using the configured model, not separate reasoning-capable models.
- The Android wrapper source is included, but a compiled APK is **not** included. Build requires Android SDK/Gradle and the final deployed URL.

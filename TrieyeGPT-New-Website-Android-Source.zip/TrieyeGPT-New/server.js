import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT=path.join(path.dirname(fileURLToPath(import.meta.url)),'public');
const PORT=Number(process.env.PORT||3000);
const MODEL=process.env.OPENAI_MODEL||'gpt-4o-mini';
const PASSWORD=process.env.TRIEYE_ACCESS_PASSWORD||'';
const LIMIT=24_000;
const counts=new Map();
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png'};
function reply(res,status,obj){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(obj));}
function security(res){res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");}
const server=http.createServer(async(req,res)=>{
 security(res);
 const pathname=new URL(req.url,'http://localhost').pathname;
 if(pathname==='/api/health')return reply(res,200,{ok:true,name:'TrieyeGPT',configured:!!process.env.OPENAI_API_KEY,passwordRequired:!!PASSWORD});
 if(pathname==='/api/chat'){
  if(req.method!=='POST')return reply(res,405,{error:'Method not allowed'});
  if(PASSWORD&&req.headers['x-trieye-password']!==PASSWORD)return reply(res,401,{error:'Incorrect access password'});
  const ip=req.socket.remoteAddress||'unknown';const now=Date.now();const entry=counts.get(ip)||{start:now,count:0};if(now-entry.start>60_000){entry.start=now;entry.count=0}if(++entry.count>20)return reply(res,429,{error:'Too many requests. Try again in one minute.'});counts.set(ip,entry);
  if(!process.env.OPENAI_API_KEY)return reply(res,503,{error:'AI API key not configured. Add OPENAI_API_KEY in Render Environment.'});
  let data='';try{for await(const chunk of req){data+=chunk;if(data.length>LIMIT)throw Error('Request too large')}const body=JSON.parse(data);const messages=body.messages;if(!Array.isArray(messages)||!messages.length||messages.length>32)throw Error('Invalid conversation');const safe=messages.map(m=>({role:m.role,content:m.content}));if(safe.some(m=>!['user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>8000))throw Error('Invalid message');const language=['English','Hindi','Telugu'].includes(body.language)?body.language:'English';const mode=['Fast','Smart','Deep'].includes(body.mode)?body.mode:'Smart';const system=`You are TrieyeGPT, a helpful, accurate AI assistant. Reply in ${language} unless user requests otherwise. Mode: ${mode}. Explain limitations and uncertainty. For programming questions, include runnable code when appropriate. Never pretend to have browsed the web or executed tools.`;
   const ctrl=new AbortController();const timeout=setTimeout(()=>ctrl.abort(),45000);let upstream;try{upstream=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'content-type':'application/json'},body:JSON.stringify({model:MODEL,messages:[{role:'system',content:system},...safe],temperature:0.6}),signal:ctrl.signal})}finally{clearTimeout(timeout)}const result=await upstream.json();if(!upstream.ok)return reply(res,502,{error:result.error?.message||'AI provider error'});return reply(res,200,{answer:result.choices?.[0]?.message?.content||'No response returned',model:result.model});
  }catch(e){return reply(res,400,{error:e.name==='AbortError'?'AI request timed out':e.message||'Request failed'})}
 }
 if(!['GET','HEAD'].includes(req.method))return reply(res,405,{error:'Method not allowed'});
 const safePath=pathname==='/'?'index.html':decodeURIComponent(pathname).replace(/^\/+/, '');const full=path.resolve(ROOT,safePath);if(!full.startsWith(ROOT+path.sep))return reply(res,403,{error:'Forbidden'});
 try{const file=await fs.readFile(full);res.writeHead(200,{'content-type':types[path.extname(full)]||'application/octet-stream','cache-control':safePath==='sw.js'?'no-cache':'public, max-age=600'});res.end(req.method==='HEAD'?undefined:file)}catch{return reply(res,404,{error:'Not found'})}
});server.listen(PORT,'0.0.0.0',()=>console.log(`TrieyeGPT running on ${PORT}`));

package com.trieyegpt.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        String home = getString(R.string.web_app_url);
        Uri allowed = Uri.parse(home);
        if (!"https".equals(allowed.getScheme()) || allowed.getHost() == null) {
            android.widget.TextView notice = new android.widget.TextView(this);
            notice.setPadding(30,50,30,30);
            notice.setText("Configure a valid HTTPS web_app_url in strings.xml, then rebuild TrieyeGPT.");
            setContentView(notice); return;
        }
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("https".equals(u.getScheme()) && allowed.getHost().equalsIgnoreCase(u.getHost())) return false;
                if ("https".equals(u.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW,u));
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl(home);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() { if(webView != null) webView.destroy(); super.onDestroy(); }
}
